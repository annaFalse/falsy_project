from django.contrib import admin

from .models import Blogs, Tags


admin.site.register(Blogs)
admin.site.register(Tags)
